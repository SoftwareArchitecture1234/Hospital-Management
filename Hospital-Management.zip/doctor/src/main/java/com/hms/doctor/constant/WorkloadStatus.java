package com.hms.doctor.constant;

public enum WorkloadStatus {
  PENDING,
  ONGOING,
  COMPLETED,
  CANCELLED
}
