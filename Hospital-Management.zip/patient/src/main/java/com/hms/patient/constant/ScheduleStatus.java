package com.hms.patient.constant;

public enum ScheduleStatus {
    PENDING,
    CONFIRMED,
    CANCELLED,
    COMPLETED,
    RESCHEDULED
}
