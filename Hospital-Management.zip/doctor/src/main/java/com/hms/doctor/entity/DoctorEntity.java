package com.hms.doctor.entity;

import jakarta.persistence.*;

@Table(name = "Doctor")
@Entity
public class DoctorEntity {

  @Id
  @Column(name = "doctor_id")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int doctorId;

  @Column(name = "name")
  private String name;

  @Column(name = "specialty")
  private String specialty;

  @Column(name = "email")
  private String email;

  @Column(name = "phone")
  private String phone;

  // Các thông tin khác nếu có

  // Getters và Setters (hoặc dùng Lombok nếu được bật)
}
