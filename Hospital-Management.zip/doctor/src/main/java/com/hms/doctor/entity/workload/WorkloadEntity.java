package com.hms.doctor.entity.workload;

import com.hms.doctor.constant.WorkloadStatus;
import com.hms.doctor.entity.DoctorEntity;
import jakarta.persistence.*;

@Table(name = "Workload")
@Entity
public class WorkloadEntity {

  @Id
  @Column(name = "workload_id")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int workloadId;

  @Column(name = "doctor_id")
  private int doctorId;

  @Column(name = "date_of_week")
  private String dateOfWeek;

  @Column(name = "type_of_work")
  private String typeOfWork;

  @Column(name = "shift")
  private String shift;

  @Column(name = "time")
  private String time;

  @Column(name = "room")
  private String room;

  @Column(name = "note", length = 1000)
  private String note;

  @Column(name = "status")
  @Enumerated(EnumType.STRING)
  private WorkloadStatus status;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "doctor_id", referencedColumnName = "doctor_id", insertable = false, updatable = false)
  private DoctorEntity doctorEntity;

  // Getters và Setters (hoặc dùng Lombok nếu đã thêm Lombok)
}
