//package com.hms.patient.entity.medicalhistory;
//
//
//import lombok.Getter;
//import lombok.Setter;
//
//@Setter
//@Getter
//public class MedicalHistoryCreateBody {
//    // Getters and setters
//    private String patientId;
//    private String diagnosis;
//    private String treatment;
//    private String notes;
//
//    // Default constructor
//    public MedicalHistoryCreateBody() {
//    }
//
//    // Constructor with all fields
//    public MedicalHistoryCreateBody(String patientId, String diagnosis, String treatment, String notes) {
//        this.patientId = patientId;
//        this.diagnosis = diagnosis;
//        this.treatment = treatment;
//        this.notes = notes;
//    }
//
//}
