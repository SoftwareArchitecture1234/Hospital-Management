package com.hms.patient.constant;


public enum Gender {
    MALE,
    FEMALE
}